#include "forbidden_domains.h"


int main()
{
    TestForbiddenDomains();
  return 0;
}
